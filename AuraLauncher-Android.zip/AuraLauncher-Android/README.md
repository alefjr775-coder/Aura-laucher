# Aura Launcher — Projeto Android

Este pacote contém o projeto Android completo do **Aura Launcher**, pronto para gerar o arquivo `.apk` tanto na nuvem (via GitHub Actions, sem instalar nada no PC) quanto localmente pelo Android Studio.

## O que está incluído
- **Interface original (`app/src/main/assets/index.html`)**: seu `Aura Launcher.html` em WebView tela cheia, com JavaScript, `localStorage` e foco para controle remoto/D-Pad ativados.
- **Ponte nativa Android (`window.AuraAndroid`)**: ao clicar em um app do catálogo, o launcher tenta abrir o aplicativo real instalado no aparelho (suporta Android TV/Leanback e celular/tablet). Se o app não estiver instalado, exibe a sobreposição original normalmente.
- **Suporte a Launcher e Android TV**: configurado com `CATEGORY_HOME`, `CATEGORY_LAUNCHER` e `CATEGORY_LEANBACK_LAUNCHER`, além de banner para Android TV.

## Opção 1: Gerar o APK grátis na nuvem (GitHub Actions)
1. Crie um repositório no [GitHub](https://github.com/new) (pode ser privado ou público).
2. Extraia este `.zip` e envie todos os arquivos da pasta `AuraLauncher-Android` para o repositório (incluindo a pasta oculta `.github/workflows/build-apk.yml`).
3. Acesse a aba **Actions** do repositório — o workflow **Build Aura Launcher APK** iniciará automaticamente (ou clique em **Run workflow**).
4. Ao concluir (cerca de 2 a 3 minutos), baixe o arquivo **`AuraLauncher-debug-apk`** na seção **Artifacts** da execução. Dentro dele estará o `app-debug.apk` pronto para instalar no Android / Android TV.

## Opção 2: Compilar no Android Studio
1. Extraia este `.zip` e abra a pasta `AuraLauncher-Android` no Android Studio.
2. Aguarde a sincronização automática do Gradle.
3. No menu superior, clique em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O arquivo será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
