-keepclassmembers class com.aura.launcher.MainActivity$AuraBridge {
    @android.webkit.JavascriptInterface <methods>;
}
